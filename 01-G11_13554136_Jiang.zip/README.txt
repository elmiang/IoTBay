Execution Steps

1. Open up Netbeans 8.2 IDE
2. Import this ZIP into the projects
3. Execute the file using the inbuilt NetBeans web preview